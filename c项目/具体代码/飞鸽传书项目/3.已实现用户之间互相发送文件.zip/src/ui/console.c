#include "ui/console.h"
#include <stdio.h>
#include <string.h>

int console_init(console_t* console) {
    if (!console) return -1;
    console->should_exit = 0;
    console->list_users_cb = NULL;
    console->send_file_cb = NULL;
    console->exit_app_cb = NULL;
    console->callback_context = NULL;
    InitializeCriticalSection(&console->print_lock);
    return 0;
}

void console_destroy(console_t* console) {
    if (!console) return;
    DeleteCriticalSection(&console->print_lock);
}

// 更新函数定义
void console_register_callbacks(console_t* console, void* context, command_callback_t list_cb, command_callback_t send_cb, command_callback_t send_file_cb, command_callback_t exit_cb) {
    if (!console) return;
    console->callback_context = context;
    console->list_users_cb = list_cb;
    console->send_msg_cb = send_cb;
    console->send_file_cb = send_file_cb; // <-- 添加此行
    console->exit_app_cb = exit_cb;
}

// 文件: src/ui/console.c

void console_run(console_t* console) {
    char buffer[256];
    while (!console->should_exit) {
        printf("> ");
        fflush(stdout);

        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            buffer[strcspn(buffer, "\r\n")] = 0; // 移除换行符

            if (strncmp(buffer, "sendfile ", 9) == 0) {
                if (console->send_file_cb) {
                    char* args[2]; // 0: index, 1: file_path
                    char* context_ptr = NULL;
                    char* token = strtok_s(buffer + 9, " ", &context_ptr);

                    if (token != NULL && context_ptr != NULL && *context_ptr != '\0') {
                        args[0] = token;
                        args[1] = context_ptr;

                        // --- 【路径解析修正】 ---
                        // 如果文件路径被双引号包裹，则移除它们
                        size_t path_len = strlen(args[1]);
                        if (path_len > 1 && args[1][0] == '"' && args[1][path_len - 1] == '"') {
                            args[1][path_len - 1] = '\0'; // 将末尾的引号替换为字符串结束符
                            args[1]++; // 将路径指针前移一位，跳过开头的引号
                        }
                        // --- 修正结束 ---

                        console->send_file_cb(console->callback_context, 2, args);

                    } else {
                        console_print_message(console, "用法: sendfile <用户编号> <文件路径>");
                    }
                }
            } else if (strncmp(buffer, "send ", 5) == 0) {
                if (console->send_msg_cb) {
                    char* args[2];
                    char* context_ptr = NULL;
                    char* token = strtok_s(buffer + 5, " ", &context_ptr);
                    if (token != NULL && context_ptr != NULL && *context_ptr != '\0') {
                        args[0] = token;
                        args[1] = context_ptr;
                        console->send_msg_cb(console->callback_context, 2, args);
                    } else {
                        console_print_message(console, "用法: send <用户编号> <消息>");
                    }
                }
            } else if (strcmp(buffer, "list") == 0) {
                if (console->list_users_cb) {
                    console->list_users_cb(console->callback_context, 0, NULL);
                }
            } else if (strcmp(buffer, "exit") == 0) {
                if (console->exit_app_cb) {
                    console->exit_app_cb(console->callback_context, 0, NULL);
                }
            } else {
                if (strlen(buffer) > 0) {
                    console_print_message(console, "未知命令。");
                }
            }
        } else {
            if (console->exit_app_cb) {
                console->exit_app_cb(console->callback_context, 0, NULL);
            }
        }
    }
}

void console_print_message(console_t* console, const char* message) {
    if (!console || !message) return;
    EnterCriticalSection(&console->print_lock);
    printf("\r%s\n", message);
    if (!console->should_exit) {
        printf("> ");
        fflush(stdout);
    }
    LeaveCriticalSection(&console->print_lock);
}

void console_display_users(console_t* console, user_list_t* user_list) {
    if (!console || !user_list) return;

    user_node_t users_snapshot[128];
    int count = user_list_get_all(user_list, users_snapshot, 128);

    EnterCriticalSection(&console->print_lock);
    printf("\r--- Online Users (%d) ---\n", count);
    if (count == 0) {
        printf("No other users found.\n");
    } else {
        for (int i = 0; i < count; ++i) {
            printf("[%d] %s (%s @ %s)\n", i,
                   users_snapshot[i].userName,
                   users_snapshot[i].hostName,
                   users_snapshot[i].ipAddress);
        }
    }
    printf("-------------------------\n");
    if (!console->should_exit) {
        printf("> ");
        fflush(stdout);
    }
    LeaveCriticalSection(&console->print_lock);
}