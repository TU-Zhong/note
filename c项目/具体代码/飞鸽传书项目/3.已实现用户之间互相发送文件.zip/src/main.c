// 文件: src/main.c

#include "core/communicator.h"
#include "ui/console.h"
#include "model/user.h"
#include "core/file_transfer.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h> // 为了 SetConsoleCP, GetFileAttributes 等函数

#include "core/protocol.h"
#include "core/protocol_parser.h"

// =================================================================
// || 上下文结构体，用于将所有模块的指针统一传递给回调函数      ||
// =================================================================
typedef struct {
    user_list_t* user_list;
    communicator_t* comm;
    console_t* console;
    file_transfer_manager_t* file_manager;
} app_context_t;


// =================================================================
// || 命令回调函数定义                                          ||
// =================================================================

/**
 * @brief 当用户在控制台输入 "list" 时被调用
 */
void on_list_command(void* context, int argc, char** argv) {
    app_context_t* app_ctx = (app_context_t*)context;
    console_display_users(app_ctx->console, app_ctx->user_list);
}

/**
 * @brief 当用户在控制台输入 "send <index> <message>" 命令时被调用
 */
void on_send_command(void* context, int argc, char** argv) {
    // 参数应为2个: [0]是用户索引, [1]是消息内容
    if (argc != 2 || argv[0] == NULL || argv[1] == NULL) {
        return;
    }

    app_context_t* app_ctx = (app_context_t*)context;
    int user_index = atoi(argv[0]); // 将字符串索引转换为整数
    const char* message = argv[1];

    // 获取当前用户列表的快照，以进行安全访问
    user_node_t users_snapshot[128];
    int count = user_list_get_all(app_ctx->user_list, users_snapshot, 128);

    // 检查用户索引是否有效
    if (user_index < 0 || user_index >= count) {
        console_print_message(app_ctx->console, "错误: 无效的用户编号。");
        return;
    }

    // 从快照中获取目标用户的信息
    user_node_t* target_user = &users_snapshot[user_index];

    // 调用网络层发送消息
    communicator_send_message(app_ctx->comm, target_user->ipAddress, target_user->port, message);

    // 在自己的控制台也显示一下发出的消息
    char self_display_buffer[512];
    snprintf(self_display_buffer, sizeof(self_display_buffer), "我 -> %s: %s", target_user->userName, message);
    console_print_message(app_ctx->console, self_display_buffer);
}

/**
 * @brief 当用户在控制台输入 "sendfile <index> <filepath>" 命令时被调用
 */
void on_send_file_command(void* context, int argc, char** argv) {
    if (argc != 2 || argv[0] == NULL || argv[1] == NULL) {
        return;
    }
    app_context_t* app_ctx = (app_context_t*)context;
    int user_index = atoi(argv[0]);
    const char* file_path = argv[1];

    // 检查文件是否存在且不是一个目录
    DWORD file_attrib = GetFileAttributes(file_path);
    if (file_attrib == INVALID_FILE_ATTRIBUTES || (file_attrib & FILE_ATTRIBUTE_DIRECTORY)) {
        console_print_message(app_ctx->console, "错误: 文件未找到或路径是一个文件夹。");
        return;
    }

    user_node_t users_snapshot[128];
    int count = user_list_get_all(app_ctx->user_list, users_snapshot, 128);
    if (user_index < 0 || user_index >= count) {
        console_print_message(app_ctx->console, "错误: 无效的用户编号。");
        return;
    }
    user_node_t* target_user = &users_snapshot[user_index];

    uint16_t tcp_port = 0;
    uint32_t file_id = (uint32_t)time(NULL); // 使用当前时间戳作为简单的文件ID

    // 1. 准备发送，在本机开启TCP监听以等待接收方连接
    if (file_transfer_prepare_send(app_ctx->file_manager, file_path, file_id, &tcp_port) != 0) {
        console_print_message(app_ctx->console, "错误: 无法准备发送文件，请检查文件权限。");
        return;
    }

    // 2. 获取文件名和大小等信息
    HANDLE hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        console_print_message(app_ctx->console, "错误: 无法读取文件信息。");
        return;
    }
    LARGE_INTEGER size;
    GetFileSizeEx(hFile, &size);
    CloseHandle(hFile);

    const char* filename = strrchr(file_path, '\\');
    if (!filename) filename = strrchr(file_path, '/');
    if (!filename) filename = file_path; else filename++;

    // 3. 通过UDP发送文件传输“信令”请求
    communicator_send_file_request(app_ctx->comm, target_user->ipAddress, target_user->port, file_id, filename, size.QuadPart, tcp_port);

    char message_buffer[MAX_PACKET_LEN];
    snprintf(message_buffer, sizeof(message_buffer), "提示: 正在向 %s 请求发送文件 '%s'，等待对方连接...", target_user->userName, filename);
    console_print_message(app_ctx->console, message_buffer);
}


/**
 * @brief 当用户在控制台输入 "exit" 时被调用
 */
void on_exit_command(void* context, int argc, char** argv) {
    app_context_t* app_ctx = (app_context_t*)context;
    if (app_ctx->console) {
        app_ctx->console->should_exit = 1;
    }
}


// =================================================================
// || 程序主入口                                                ||
// =================================================================
int main(int argc, char* argv[]) {
    // 【编码修复】设置控制台为UTF-8模式，以正确处理中文输入输出
    // 设置控制台为UTF-8模式
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    // 检查命令行参数
    if (argc < 2) {
        printf("用法: %s <用户名> [端口号]\n", argv[0]);
        printf("示例: %s 用户A 2425\n", argv[0]);
        printf("如果未指定端口，将默认使用 2425。\n");
        return 1;
    }
    const char* user_name = argv[1];
    int port = (argc > 2) ? atoi(argv[2]) : IPMSG_DEFAULT_PORT;

    // 1. 初始化 Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup 失败。\n");
        return 1;
    }

    // 2. 初始化所有模块
    communicator_t comm = {0};
    user_list_t user_list = {0};
    console_t console = {0};
    file_transfer_manager_t file_manager = {0};

    // 创建并设置统一的上下文，方便回调函数访问所有模块
    app_context_t app_ctx = { &user_list, &comm, &console, &file_manager };

    user_list_init(&user_list);
    console_init(&console);
    file_transfer_init(&file_manager);

    // 注册所有回调函数
    console_register_callbacks(&console, &app_ctx, on_list_command, on_send_command, on_send_file_command, on_exit_command);

    // 初始化通信模块
    if (communicator_init(&comm, &user_list, &console, user_name, port) != 0) {
        printf("Communicator 初始化失败。\n");
        file_transfer_destroy(&file_manager);
        user_list_destroy(&user_list);
        console_destroy(&console);
        WSACleanup();
        return 1;
    }

    printf("欢迎, %s! 您的客户端正在端口 %d 上运行。\n", user_name, port);
    printf("--------------------------------------------------\n");
    printf("命令:\n");
    printf("  list                  - 显示在线用户\n");
    printf("  send <编号> <消息>   - 发送消息\n");
    printf("  sendfile <编号> <路径> - 发送文件\n");
    printf("  exit                  - 退出程序\n");
    printf("--------------------------------------------------\n");

    // 3. 广播上线通知
    communicator_broadcast_entry(&comm);

    // 4. 运行控制台主循环
    console_run(&console);

    // 5. 程序退出前广播下线通知
    printf("正在广播下线通知...\n");
    communicator_broadcast_exit(&comm);

    // 6. 按顺序清理和销毁所有模块
    communicator_destroy(&comm);
    file_transfer_destroy(&file_manager);
    user_list_destroy(&user_list);
    console_destroy(&console);
    WSACleanup();

    printf("清理完成。再见！\n");
    return 0;
}