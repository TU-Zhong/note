// 文件: src/core/communicator.c

// 【修正】保证头文件包含顺序的整洁
#include <winsock2.h>
#include <ws2tcpip.h>
#include <Mstcpip.h>
#include <stdio.h>
#include <time.h>
#include <process.h>

#include "core/communicator.h"
#include "core/protocol.h"
#include "core/protocol_parser.h"
#include "ui/console.h"
#include "model/user.h"
#include "core/file_transfer.h"

// 定义模拟广播的端口范围
#define SIMULATED_BROADCAST_PORT_START 2425
#define SIMULATED_BROADCAST_PORT_END   2435

// --- 内部函数声明 ---

// --- 内部函数声明 ---
static void process_packet(communicator_t* comm, const char* source_ip, uint16_t source_port, const parsed_message_t* msg);
static unsigned __stdcall communicator_listen_loop(void* param);
static void simulate_broadcast(communicator_t* comm, const char* buffer, int len);

// --- 线程主函数 ---
static unsigned __stdcall communicator_listen_loop(void* param) {
    communicator_t* comm = (communicator_t*)param;
    char recv_buffer[MAX_PACKET_LEN];
    struct sockaddr_in sender_addr;
    int sender_addr_len = sizeof(sender_addr);

    while (comm->is_running) {
        int bytes_received = recvfrom(comm->sock, recv_buffer, sizeof(recv_buffer) - 1, 0, (struct sockaddr*)&sender_addr, &sender_addr_len);
        if (bytes_received <= 0) {
            if (!comm->is_running) break;
            continue;
        }
        recv_buffer[bytes_received] = '\0';
        parsed_message_t parsed_msg = {0};
        if (parse_message(recv_buffer, bytes_received, &parsed_msg) == 0) {
            const char* source_ip = inet_ntoa(sender_addr.sin_addr);
            uint16_t source_port = ntohs(sender_addr.sin_port);
            process_packet(comm, source_ip, source_port, &parsed_msg);
        }
    }
    return 0;
}

// --- 内部消息处理器 ---
static void process_packet(communicator_t* comm, const char* source_ip, uint16_t source_port, const parsed_message_t* msg) {
    // 【逻辑修正】只忽略自己发出的广播包，但要处理别人对我们上线包的回应
    if (strcmp(msg->sender_name, comm->user_name) == 0 && msg->command != IPMSG_ANSENTRY) {
        return;
    }

    user_node_t new_user = {0};
    strcpy_s(new_user.userName, sizeof(new_user.userName), msg->sender_name);
    strcpy_s(new_user.hostName, sizeof(new_user.hostName), msg->sender_host);
    strcpy_s(new_user.ipAddress, sizeof(new_user.ipAddress), source_ip);
    new_user.port = source_port;

    switch (msg->command) {
        case IPMSG_BR_ENTRY:
            user_list_add(comm->user_list, &new_user);
            communicator_send_ans_entry(comm, source_ip, source_port);
            break;
        case IPMSG_ANSENTRY:
            user_list_add(comm->user_list, &new_user);
            break;
        case IPMSG_BR_EXIT:
            user_list_remove(comm->user_list, source_ip, source_port);
            break;
        case IPMSG_SENDMSG: {
            char message_buffer[MAX_PACKET_LEN];
            snprintf(message_buffer, sizeof(message_buffer), "[%s]: %s", msg->sender_name, msg->additional_section);
            console_print_message(comm->console, message_buffer);
            break;
        }
        case IPMSG_REQUEST_FILE_SEND: {
            file_info_t finfo;
            uint16_t tcp_port;
            int items = sscanf_s(msg->additional_section, "%u:%[^:]:%llx:%hu",
                               &finfo.file_id,
                               finfo.file_name, (unsigned)_countof(finfo.file_name),
                               &finfo.file_size,
                               &tcp_port);

            if (items == 4) {
                char message_buffer[MAX_PACKET_LEN];
                snprintf(message_buffer, sizeof(message_buffer), "提示: 用户 '%s' 想给您发送文件 '%s' (%llu 字节). 已自动开始接收。", msg->sender_name, finfo.file_name, finfo.file_size);
                console_print_message(comm->console, message_buffer);

                // 通过console的回调上下文获取app_context指针
                void* context = comm->console->callback_context;
                typedef struct { void* u; void* c; void* o; file_transfer_manager_t* file_manager; } app_context_t;

                if(context) {
                    file_transfer_start_receive(((app_context_t*)context)->file_manager, source_ip, tcp_port, &finfo);
                }
            }
            break;
        }
    }
}


// 文件: src/core/communicator.c

// --- 模拟广播 ---
static void simulate_broadcast(communicator_t* comm, const char* buffer, int len) {
    if (!comm || comm->sock == INVALID_SOCKET || !buffer || len <= 0) return;
    struct sockaddr_in dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.sin_family = AF_INET;
    inet_pton(AF_INET, "127.0.0.1", &dest_addr.sin_addr);

    for (int port = SIMULATED_BROADCAST_PORT_START; port <= SIMULATED_BROADCAST_PORT_END; ++port) {
        // 不向自己当前监听的UDP端口广播
        int current_port = 0;
        struct sockaddr_in sin;
        int addrlen = sizeof(sin);
        if (getsockname(comm->sock, (struct sockaddr *)&sin, &addrlen) == 0) {
            current_port = ntohs(sin.sin_port);
        }
        if (current_port == port) continue;

        dest_addr.sin_port = htons((uint16_t)port);
        sendto(comm->sock, buffer, len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
    }
}

// --- 公共接口函数 ---
// 文件: src/core/communicator.c

// --- 公共接口函数 ---
int communicator_init(communicator_t* comm, user_list_t* user_list, struct Console* console, const char* user_name, int port) {
    if (!comm || !user_list || !console || !user_name) return -1;
    comm->user_list = user_list;
    comm->console = console;
    comm->is_running = 1;
    comm->packet_counter = (uint64_t)time(NULL);
    strcpy_s(comm->user_name, sizeof(comm->user_name), user_name);
    gethostname(comm->host_name, sizeof(comm->host_name));

    comm->sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (comm->sock == INVALID_SOCKET) return -1;

    // 手动定义 SIO_UDP_CONNRESET 以解决编译问题
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif
    DWORD dwBytesReturned = 0;
    BOOL bNewBehavior = FALSE;
    WSAIoctl(comm->sock, SIO_UDP_CONNRESET, &bNewBehavior, sizeof(bNewBehavior), NULL, 0, &dwBytesReturned, NULL, NULL);

    struct sockaddr_in local_addr;
    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_port = htons((uint16_t)port);
    local_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(comm->sock, (struct sockaddr*)&local_addr, sizeof(local_addr)) == SOCKET_ERROR) {
        closesocket(comm->sock);
        return -1;
    }

    comm->listen_thread_handle = _beginthreadex(NULL, 0, communicator_listen_loop, comm, 0, NULL);
    if (comm->listen_thread_handle == 0) {
        closesocket(comm->sock);
        return -1;
    }
    return 0;
}

void communicator_destroy(communicator_t* comm) {
    if (!comm) return;
    comm->is_running = 0;
    if (comm->sock != INVALID_SOCKET) {
        closesocket(comm->sock);
        comm->sock = INVALID_SOCKET;
    }
    if (comm->listen_thread_handle != 0) {
        WaitForSingleObject((HANDLE)comm->listen_thread_handle, INFINITE);
        CloseHandle((HANDLE)comm->listen_thread_handle);
    }
}

void communicator_broadcast_entry(communicator_t* comm) {
    if (!comm) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = build_entry_packet(buffer, sizeof(buffer), comm->packet_counter++, comm->user_name, comm->host_name);
    if (packet_len > 0) simulate_broadcast(comm, buffer, packet_len);
}

void communicator_broadcast_exit(communicator_t* comm) {
    if (!comm) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = build_exit_packet(buffer, sizeof(buffer), comm->packet_counter++, comm->user_name, comm->host_name);
    if (packet_len > 0) simulate_broadcast(comm, buffer, packet_len);
}

void communicator_send_ans_entry(communicator_t* comm, const char* dest_ip, uint16_t dest_port) {
    if (!comm || comm->sock == INVALID_SOCKET) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = snprintf(buffer, sizeof(buffer), "%d:%llu:%s:%s:%u:%s", IPMSG_PROTOCOL_VERSION, comm->packet_counter++, comm->user_name, comm->host_name, IPMSG_ANSENTRY, comm->user_name);
    if (packet_len < 0) return;
    struct sockaddr_in dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(dest_port);
    inet_pton(AF_INET, dest_ip, &dest_addr.sin_addr);
    sendto(comm->sock, buffer, packet_len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
}

void communicator_send_message(communicator_t* comm, const char* dest_ip, uint16_t dest_port, const char* message) {
    if (!comm || !dest_ip || !message) return;

    char buffer[MAX_PACKET_LEN] = {0};
    // 调用第1步创建的函数来构建数据包
    int packet_len = build_sendmsg_packet(buffer, sizeof(buffer), comm->packet_counter++, comm->user_name, comm->host_name, message);

    if (packet_len > 0) {
        struct sockaddr_in dest_addr;
        memset(&dest_addr, 0, sizeof(dest_addr));
        dest_addr.sin_family = AF_INET;
        dest_addr.sin_port = htons(dest_port);
        inet_pton(AF_INET, dest_ip, &dest_addr.sin_addr);

        // 发送数据
        sendto(comm->sock, buffer, packet_len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
    }
}

// 文件: src/core/communicator.c
void communicator_send_file_request(communicator_t* comm, const char* dest_ip, uint16_t dest_port, uint32_t file_id, const char* file_name, uint64_t file_size, uint16_t tcp_port) {
    if (!comm || !dest_ip || !file_name) return;

    char buffer[MAX_PACKET_LEN] = {0};
    char additional_section[MAX_ADDITIONAL_LEN];
    // 附加信息格式: 文件ID:文件名:文件大小:TCP端口
    snprintf(additional_section, sizeof(additional_section), "%u:%s:%llx:%u", file_id, file_name, file_size, tcp_port);

    int packet_len = snprintf(buffer, sizeof(buffer), "%d:%llu:%s:%s:%u:%s",
                            IPMSG_PROTOCOL_VERSION, comm->packet_counter++, comm->user_name, comm->host_name,
                            IPMSG_REQUEST_FILE_SEND, additional_section);

    if (packet_len > 0) {
        struct sockaddr_in dest_addr;
        memset(&dest_addr, 0, sizeof(dest_addr));
        dest_addr.sin_family = AF_INET;
        dest_addr.sin_port = htons(dest_port);
        inet_pton(AF_INET, dest_ip, &dest_addr.sin_addr);
        sendto(comm->sock, buffer, packet_len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
    }
}