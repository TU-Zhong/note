// 文件: src/core/file_transfer.h

#ifndef FILE_TRANSFER_H
#define FILE_TRANSFER_H

#include <stdint.h>
#include <winsock2.h> // 需要网络类型

#define MAX_FILE_PATH 260

// 文件基本信息
typedef struct {
    uint32_t file_id;
    char file_name[MAX_FILE_PATH];
    uint64_t file_size;
} file_info_t;

// 代表一次文件传输会话的结构体
typedef struct {
    SOCKET sock;
    uintptr_t thread_handle;
    file_info_t file_info;
    char target_ip[16];
    uint16_t target_port; // 用于接收方连接发送方
    char local_file_path[MAX_FILE_PATH]; // 用于发送方读取或接收方保存

    // --- 【关键修正】 ---
    // 添加一个合法的成员来传递 manager 指针
    struct file_transfer_manager_t* manager;
} file_transfer_session_t;

// 文件传输管理器
typedef struct {
    volatile long active_transfers; // 使用原子操作更安全
    CRITICAL_SECTION lock;
    // 未来可以扩展，比如用一个链表管理所有会话
} file_transfer_manager_t;

int file_transfer_init(file_transfer_manager_t* manager);
void file_transfer_destroy(file_transfer_manager_t* manager);

// 发送方调用此函数：准备接收连接，并返回监听的TCP端口
int file_transfer_prepare_send(file_transfer_manager_t* manager, const char* file_path, uint32_t file_id, uint16_t* out_tcp_port);

// 接收方调用此函数：连接到发送方并开始接收文件
int file_transfer_start_receive(file_transfer_manager_t* manager, const char* target_ip, uint16_t target_port, const file_info_t* file_info);

#endif //FILE_TRANSFER_H