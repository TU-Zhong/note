// 文件: src/core/file_transfer.c

#include "core/file_transfer.h"
#include <windows.h>
#include <stdio.h>
#include <process.h> // for _beginthreadex
#include <ws2tcpip.h>

#define BUFFER_SIZE 65536 // 64KB

// --- 内部线程函数 ---

// 文件: src/core/file_transfer.c

static unsigned __stdcall sender_thread_proc(void* param) {
    file_transfer_session_t* session = (file_transfer_session_t*)param;
    // 【修正】从合法的成员变量中安全地获取 manager 指针
    file_transfer_manager_t* manager = session->manager;

    struct sockaddr_in client_addr;
    int client_len = sizeof(client_addr);
    SOCKET client_sock = accept(session->sock, (struct sockaddr*)&client_addr, &client_len);

    closesocket(session->sock); // 监听socket的任务已完成，可以关闭
    session->sock = INVALID_SOCKET;

    if (client_sock == INVALID_SOCKET) {
        printf("FileTransfer Error: accept() failed.\n");
        free(session);
        InterlockedDecrement(&manager->active_transfers);
        return 1;
    }

    printf("FileTransfer Info: Connection accepted. Starting to send '%s'.\n", session->file_info.file_name);
    fflush(stdout);

    FILE* file = NULL;
    fopen_s(&file, session->local_file_path, "rb"); // 以二进制只读方式打开文件
    if (!file) {
        printf("FileTransfer Error: Failed to open file '%s'.\n", session->local_file_path);
        closesocket(client_sock);
        free(session);
        InterlockedDecrement(&manager->active_transfers);
        return 1;
    }

    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
        if (send(client_sock, buffer, (int)bytes_read, 0) == SOCKET_ERROR) {
            printf("FileTransfer Error: send() failed.\n");
            break;
        }
    }

    fclose(file);
    closesocket(client_sock);
    printf("FileTransfer Info: Finished sending '%s'.\n", session->file_info.file_name);
    fflush(stdout);

    free(session);
    InterlockedDecrement(&manager->active_transfers);
    return 0;
}


// 接收方线程：连接到服务器，然后接收文件数据
// 文件: src/core/file_transfer.c

static unsigned __stdcall receiver_thread_proc(void* param) {
    file_transfer_session_t* session = (file_transfer_session_t*)param;
    // 【修正】从合法的成员变量中安全地获取 manager 指针
    file_transfer_manager_t* manager = session->manager;

    session->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (session->sock == INVALID_SOCKET) {
        printf("FileTransfer Error: receiver socket() failed.\n");
        free(session);
        InterlockedDecrement(&manager->active_transfers);
        return 1;
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(session->target_port);
    inet_pton(AF_INET, session->target_ip, &server_addr.sin_addr);

    // 保留的诊断日志，用于确认连接目标
    printf("DEBUG: Receiver is attempting to connect to %s on port %u...\n", session->target_ip, session->target_port);
    fflush(stdout);

    if (connect(session->sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("FileTransfer Error: connect() to %s:%u failed. Error code: %d\n", session->target_ip, session->target_port, WSAGetLastError());
        closesocket(session->sock);
        free(session);
        InterlockedDecrement(&manager->active_transfers);
        return 1;
    }

    printf("FileTransfer Info: Connected to sender. Starting to receive '%s'.\n", session->file_info.file_name);
    fflush(stdout);

    FILE* file = NULL;
    fopen_s(&file, session->file_info.file_name, "wb"); // 在当前目录创建文件并以二进制写入
    if (!file) {
        printf("FileTransfer Error: Failed to create file '%s'.\n", session->file_info.file_name);
        closesocket(session->sock);
        free(session);
        InterlockedDecrement(&manager->active_transfers);
        return 1;
    }

    char buffer[BUFFER_SIZE];
    int bytes_received;
    while ((bytes_received = recv(session->sock, buffer, BUFFER_SIZE, 0)) > 0) {
        fwrite(buffer, 1, bytes_received, file);
    }

    fclose(file);
    closesocket(session->sock);
    printf("FileTransfer Info: Finished receiving '%s'. Size: %llu bytes.\n", session->file_info.file_name, session->file_info.file_size);
    fflush(stdout);

    free(session);
    InterlockedDecrement(&manager->active_transfers);
    return 0;
}


// --- 公共接口函数 ---

int file_transfer_init(file_transfer_manager_t* manager) {
    if (!manager) return -1;
    manager->active_transfers = 0;
    InitializeCriticalSection(&manager->lock);
    return 0;
}

void file_transfer_destroy(file_transfer_manager_t* manager) {
    if (!manager) return;
    // 等待所有传输完成 (简化版，实际应有更复杂逻辑)
    while(manager->active_transfers > 0) {
        Sleep(100);
    }
    DeleteCriticalSection(&manager->lock);
}

int file_transfer_prepare_send(file_transfer_manager_t* manager, const char* file_path, uint32_t file_id, uint16_t* out_tcp_port) {
    if (!manager || !file_path || !out_tcp_port) return -1;

    file_transfer_session_t* session = (file_transfer_session_t*)malloc(sizeof(file_transfer_session_t));
    if (!session) return -1;
    memset(session, 0, sizeof(file_transfer_session_t));

    // 【修正】通过新成员来安全地传递manager指针
    session->manager = manager;

    // 填充会话信息
    session->file_info.file_id = file_id;
    strcpy_s(session->local_file_path, sizeof(session->local_file_path), file_path);
    const char* filename = strrchr(file_path, '\\');
    if (!filename) filename = strrchr(file_path, '/');
    if (!filename) filename = file_path; else filename++;
    strcpy_s(session->file_info.file_name, sizeof(session->file_info.file_name), filename);

    HANDLE hFile = CreateFile(file_path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) { free(session); return -1; }
    LARGE_INTEGER size;
    GetFileSizeEx(hFile, &size);
    session->file_info.file_size = size.QuadPart;
    CloseHandle(hFile);

    session->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (session->sock == INVALID_SOCKET) { free(session); return -1; }

    struct sockaddr_in listen_addr;
    listen_addr.sin_family = AF_INET;
    listen_addr.sin_addr.s_addr = INADDR_ANY;
    listen_addr.sin_port = 0; // 绑定到随机端口

    if (bind(session->sock, (struct sockaddr*)&listen_addr, sizeof(listen_addr)) == SOCKET_ERROR) {
        closesocket(session->sock); free(session); return -1;
    }

    int addr_len = sizeof(listen_addr);
    getsockname(session->sock, (struct sockaddr*)&listen_addr, &addr_len);
    *out_tcp_port = ntohs(listen_addr.sin_port); // 获取并返回端口

    if (listen(session->sock, 1) == SOCKET_ERROR) {
        closesocket(session->sock); free(session); return -1;
    }

    uintptr_t handle = _beginthreadex(NULL, 0, sender_thread_proc, session, 0, NULL);
    if (handle == 0) {
        closesocket(session->sock); free(session); return -1;
    }

    InterlockedIncrement(&manager->active_transfers);
    CloseHandle((HANDLE)handle);
    return 0;
}

// 文件: src/core/file_transfer.c

int file_transfer_start_receive(file_transfer_manager_t* manager, const char* target_ip, uint16_t target_port, const file_info_t* file_info) {
    if (!manager || !target_ip || !file_info) return -1;

    file_transfer_session_t* session = (file_transfer_session_t*)malloc(sizeof(file_transfer_session_t));
    if (!session) {
        printf("\nFATAL ERROR: malloc for session failed.\n");
        return -1;
    }
    memset(session, 0, sizeof(file_transfer_session_t));

    // 【修正】通过新成员来安全地传递manager指针
    session->manager = manager;

    // 填充会话信息
    session->target_port = target_port;
    strcpy_s(session->target_ip, sizeof(session->target_ip), target_ip);
    memcpy(&session->file_info, file_info, sizeof(file_info_t));

    // 使用我们最终极的错误诊断版本
    uintptr_t handle = _beginthreadex(NULL, 0, receiver_thread_proc, session, 0, NULL);
    if (handle == 0) {
        DWORD error_code = GetLastError();
        char error_buffer[256];
        FormatMessageA(
            FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
            NULL,
            error_code,
            MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
            error_buffer,
            sizeof(error_buffer),
            NULL
        );
        printf("\n==================== FATAL ERROR ====================\n");
        printf("Failed to create receiver thread.\n");
        printf("System Error Code: %lu\n", error_code);
        printf("System Error Message: %s", error_buffer);
        printf("=====================================================\n");
        fflush(stdout);
        free(session);
        return -1;
    }

    InterlockedIncrement(&manager->active_transfers);
    CloseHandle((HANDLE)handle);
    return 0;
}