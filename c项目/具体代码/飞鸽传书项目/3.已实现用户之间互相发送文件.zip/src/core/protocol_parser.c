#include "core/protocol_parser.h"
#include "core/protocol.h"
#include <string.h>
#include <stdio.h>
#include <windows.h> // 为了 GetFileSizeEx

int build_entry_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name) {
    if (buffer == NULL || user_name == NULL || host_name == NULL) {
        return -1;
    }

    int main_part_len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:",
        IPMSG_PROTOCOL_VERSION, packet_no, user_name, host_name, IPMSG_BR_ENTRY);

    if (main_part_len < 0 || (size_t)main_part_len >= buffer_size) {
        return -2;
    }

    size_t user_len = strlen(user_name);
    if ((size_t)main_part_len + user_len + 2 > buffer_size) {
        return -2;
    }
    memcpy(buffer + main_part_len, user_name, user_len);
    buffer[main_part_len + user_len] = '\0';
    buffer[main_part_len + user_len + 1] = '\0';

    return main_part_len + (int)user_len + 2;
}

int build_exit_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name) {
    if (buffer == NULL || user_name == NULL || host_name == NULL) {
        return -1;
    }

    int len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:%s",
        IPMSG_PROTOCOL_VERSION, packet_no, user_name, host_name, IPMSG_BR_EXIT, user_name);

    if (len < 0 || (size_t)len >= buffer_size) {
        return -2;
    }
    return len;
}

int parse_message(const char* packet, size_t packet_len, parsed_message_t* out_msg) {
    if (packet == NULL || out_msg == NULL || packet_len == 0) {
        return -1;
    }

    unsigned int command_and_options;
    int items_scanned = sscanf_s(packet, "%d:%llu:%[^:]:%[^:]:%u:",
        &out_msg->version,
        &out_msg->packet_no,
        out_msg->sender_name, (unsigned)_countof(out_msg->sender_name),
        out_msg->sender_host, (unsigned)_countof(out_msg->sender_host),
        &command_and_options);

    if (items_scanned != 5) {
        return -2;
    }

    out_msg->command = command_and_options & 0xFF;
    out_msg->option = command_and_options;

    const char* additional_start = packet;
    for (int i = 0; i < 5; ++i) {
        if ((additional_start = strchr(additional_start, ':')) == NULL) return -2;
        additional_start++;
    }

    size_t main_part_len = additional_start - packet;
    if (main_part_len >= packet_len) {
        out_msg->additional_section[0] = '\0';
    } else {
        size_t additional_len = packet_len - main_part_len;
        if (additional_len >= sizeof(out_msg->additional_section)) {
            additional_len = sizeof(out_msg->additional_section) - 1;
        }
        memcpy(out_msg->additional_section, additional_start, additional_len);
        out_msg->additional_section[additional_len] = '\0';
    }

    return 0;
}
//创建一个符合ipmsg的数据包
int build_sendmsg_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name, const char* message) {
    if (buffer == NULL || user_name == NULL || host_name == NULL || message == NULL) {
        return -1;
    }

    // 格式化数据包： 版本:包编号:用户名:主机名:命令:附加消息
    int len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:%s",
        IPMSG_PROTOCOL_VERSION,
        packet_no,
        user_name,
        host_name,
        IPMSG_SENDMSG, // 使用发送消息的命令
        message);

    if (len < 0 || (size_t)len >= buffer_size) {
        return -2; // 缓冲区太小或发生错误
    }

    return len; // 返回数据包的实际长度
}

int build_file_request_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name, uint32_t file_id, const char* file_name, uint64_t file_size) {
    if (!buffer || !user_name || !host_name || !file_name) return -1;

    // 附加信息格式: 文件ID:文件名:文件大小(十六进制)
    // 我们用一个子缓冲区来格式化附加信息
    char additional_section[MAX_ADDITIONAL_LEN];
    snprintf(additional_section, sizeof(additional_section), "%u:%s:%llx",
             file_id,
             file_name,
             file_size);

    // 构建完整的数据包
    int len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:%s",
                     IPMSG_PROTOCOL_VERSION,
                     packet_no,
                     user_name,
                     host_name,
                     IPMSG_REQUEST_FILE_SEND, // 使用文件请求命令
                     additional_section);

    if (len < 0 || (size_t)len >= buffer_size) {
        return -2;
    }

    return len;
}