#ifndef USER_H
#define USER_H

#include <stdint.h>
// #include <wincock2.h>
#include <windows.h>

#define MAX_NAME_LEN 64
#define MAX_HOSTNAME_LEN 64
#define MAX_IP_LEN 16

typedef struct UserNode {
    char userName[MAX_NAME_LEN];
    char groupName[MAX_HOSTNAME_LEN];
    char hostName[MAX_HOSTNAME_LEN];
    char ipAddress[MAX_IP_LEN];
    uint16_t port;
    struct UserNode* next;
} user_node_t;

typedef struct {
    user_node_t* head;
    int count;
    CRITICAL_SECTION lock;
} user_list_t;

int user_list_init(user_list_t* list);
void user_list_destroy(user_list_t* list);
void user_list_add(user_list_t* list, const user_node_t* user_data);
void user_list_remove(user_list_t* list, const char* ip_address, uint16_t port);
int user_list_get_all(user_list_t* list, user_node_t dest_array[], int max_count);
void user_list_clear(user_list_t* list);

#endif //USER_H