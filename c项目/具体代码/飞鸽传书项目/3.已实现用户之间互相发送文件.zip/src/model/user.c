#include "model/user.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int user_list_init(user_list_t* list) {
    if (!list) return -1;
    list->head = NULL;
    list->count = 0;
    InitializeCriticalSection(&list->lock);
    return 0;
}

void user_list_destroy(user_list_t* list) {
    if (!list) return;
    user_list_clear(list);
    DeleteCriticalSection(&list->lock);
}

void user_list_add(user_list_t* list, const user_node_t* user_data) {
    if (!list || !user_data) return;

    EnterCriticalSection(&list->lock);
    printf("--- user_list_add: entered for user '%s' ---\n", user_data->userName);

    user_node_t* current = list->head;
    int existed = 0;
    while (current != NULL) {
        if (strcmp(current->ipAddress, user_data->ipAddress) == 0 && current->port == user_data->port) {
            printf("--- user_list_add: User '%s' already exists. Updating info. ---\n", user_data->userName);
            strcpy_s(current->userName, sizeof(current->userName), user_data->userName);
            strcpy_s(current->hostName, sizeof(current->hostName), user_data->hostName);
            existed = 1;
            break;
        }
        current = current->next;
    }

    if (!existed) {
        printf("--- user_list_add: User '%s' is new. Attempting to add. ---\n", user_data->userName);
        user_node_t* new_node = (user_node_t*)malloc(sizeof(user_node_t));
        if (new_node) {
            printf("--- user_list_add: malloc successful. Adding node. ---\n");
            memcpy(new_node, user_data, sizeof(user_node_t));
            new_node->next = list->head;
            list->head = new_node;
            list->count++;
        } else {
            printf("--- user_list_add: FATAL ERROR - malloc failed! ---\n");
        }
    }
    
    printf("--- user_list_add: finished. Current count: %d ---\n", list->count);
    LeaveCriticalSection(&list->lock);
}

void user_list_remove(user_list_t* list, const char* ip_address, uint16_t port) {
    if (!list || !ip_address) return;

    EnterCriticalSection(&list->lock);

    user_node_t* current = list->head;
    user_node_t* prev = NULL;

    while (current != NULL) {
        if (strcmp(current->ipAddress, ip_address) == 0 && current->port == port) {
            if (prev == NULL) {
                list->head = current->next;
            } else {
                prev->next = current->next;
            }
            printf("--- user_list_remove: User '%s' left. Removing node. ---\n", current->userName);
            free(current);
            list->count--;
            break;
        }
        prev = current;
        current = current->next;
    }

    LeaveCriticalSection(&list->lock);
}

void user_list_clear(user_list_t* list) {
    if(!list) return;
    EnterCriticalSection(&list->lock);
    user_node_t* current = list->head;
    while(current != NULL) {
        user_node_t* next = current->next;
        free(current);
        current = next;
    }
    list->head = NULL;
    list->count = 0;
    LeaveCriticalSection(&list->lock);
}

int user_list_get_all(user_list_t* list, user_node_t dest_array[], int max_count) {
    if (!list || !dest_array) return 0;
    
    EnterCriticalSection(&list->lock);
    
    int i = 0;
    user_node_t* current = list->head;
    while (current != NULL && i < max_count) {
        memcpy(&dest_array[i], current, sizeof(user_node_t));
        i++;
        current = current->next;
    }
    
    LeaveCriticalSection(&list->lock);
    return i;
}