#include "core/file_transfer.h"

int file_transfer_init(file_transfer_manager_t* manager) {
    if (!manager) return -1;
    manager->active_transfers = 0;
    return 0;
}

void file_transfer_destroy(file_transfer_manager_t* manager) {
    // a
}

int file_transfer_prepare_send(file_transfer_manager_t* manager, const char* file_path, uint16_t* out_tcp_port) {
    return -1; // Not implemented
}

int file_transfer_start_receive(file_transfer_manager_t* manager, const char* target_ip, uint16_t target_port, const file_info_t* file_info) {
    return -1; // Not implemented
}