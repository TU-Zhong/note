#ifndef FILE_TRANSFER_H
#define FILE_TRANSFER_H

#include <stdint.h>

#define MAX_FILE_PATH 260

typedef struct {
    uint32_t file_id;
    char file_name[MAX_FILE_PATH];
    uint64_t file_size;
} file_info_t;

typedef struct {
    volatile int active_transfers;
} file_transfer_manager_t;

int file_transfer_init(file_transfer_manager_t* manager);
void file_transfer_destroy(file_transfer_manager_t* manager);
int file_transfer_prepare_send(file_transfer_manager_t* manager, const char* file_path, uint16_t* out_tcp_port);
int file_transfer_start_receive(file_transfer_manager_t* manager, const char* target_ip, uint16_t target_port, const file_info_t* file_info);

#endif //FILE_TRANSFER_H