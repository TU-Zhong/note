#ifndef COMMUNICATOR_H
#define COMMUNICATOR_H

#include <winsock2.h>
#include <windows.h>
#include <stdint.h>
#include "../model/user.h"

struct Console;

typedef struct {
    SOCKET sock;
    uintptr_t listen_thread_handle;
    volatile int is_running;
    uint64_t packet_counter;
    char user_name[MAX_NAME_LEN];
    char host_name[MAX_HOSTNAME_LEN];
    user_list_t* user_list;
    struct Console* console;
} communicator_t;

int communicator_init(communicator_t* comm, user_list_t* user_list, struct Console* console, const char* user_name, int port);
void communicator_destroy(communicator_t* comm);
void communicator_broadcast_entry(communicator_t* comm);
void communicator_broadcast_exit(communicator_t* comm);
void communicator_send_ans_entry(communicator_t* comm, const char* dest_ip, uint16_t dest_port);

#endif //COMMUNICATOR_H