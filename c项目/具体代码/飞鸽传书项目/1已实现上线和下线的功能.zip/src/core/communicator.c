// 【关键修复】严格保证Windows网络头文件的包含顺序
#include <winsock2.h>
#include <ws2tcpip.h>
// 包含其他C标准库和我们项目自己的头文件
#include <stdio.h>
#include <time.h>
#include <process.h>
#include "core/communicator.h"
#include "core/protocol.h"
#include "core/protocol_parser.h"
#include "ui/console.h"
#include "model/user.h"

// 将 Mstcpip.h 移动到所有其他头文件之后，以防止 _WIN32_WINNT 被覆盖
#if defined(_WIN32_WINNT) && (_WIN32_WINNT < 0x0600)
    #error _WIN32_WINNT has been redefined to a value lower than 0x0600! The header included right above this line is the culprit!
#elif !defined(_WIN32_WINNT)
    #error _WIN32_WINNT has been undefined! The header included right above this line is the culprit!
#endif
#include <Mstcpip.h>




// 定义模拟广播的端口范围
#define SIMULATED_BROADCAST_PORT_START 2425
#define SIMULATED_BROADCAST_PORT_END   2435
// #define _WIN32_WINNT 0x0600 // 这是正确的

// --- 内部辅助函数的前向声明 ---
// (由于我们把所有函数定义都放在这个文件里，且顺序正确，理论上不再需要前向声明)
static void process_packet(communicator_t* comm, const char* source_ip, uint16_t source_port, const parsed_message_t* msg);
static unsigned __stdcall communicator_listen_loop(void* param);
static void simulate_broadcast(communicator_t* comm, const char* buffer, int len);

// --- 线程主函数 ---
static unsigned __stdcall communicator_listen_loop(void* param) {
    communicator_t* comm = (communicator_t*)param;
    char recv_buffer[MAX_PACKET_LEN];
    struct sockaddr_in sender_addr;
    int sender_addr_len = sizeof(sender_addr);
    while (comm->is_running) {
        int bytes_received = recvfrom(comm->sock, recv_buffer, sizeof(recv_buffer) - 1, 0, (struct sockaddr*)&sender_addr, &sender_addr_len);
        if (bytes_received <= 0) {
            if (!comm->is_running) break;
            continue;
        }
        recv_buffer[bytes_received] = '\0';
        parsed_message_t parsed_msg = {0};
        if (parse_message(recv_buffer, bytes_received, &parsed_msg) == 0) {
            const char* source_ip = inet_ntoa(sender_addr.sin_addr);
            uint16_t source_port = ntohs(sender_addr.sin_port);
            process_packet(comm, source_ip, source_port, &parsed_msg);
        }
    }
    return 0;
}

// --- 内部消息处理器 ---
static void process_packet(communicator_t* comm, const char* source_ip, uint16_t source_port, const parsed_message_t* msg) {
    if (strcmp(msg->sender_name, comm->user_name) == 0) {
        return;
    }
    user_node_t new_user = {0};
    strcpy_s(new_user.userName, sizeof(new_user.userName), msg->sender_name);
    strcpy_s(new_user.hostName, sizeof(new_user.hostName), msg->sender_host);
    strcpy_s(new_user.ipAddress, sizeof(new_user.ipAddress), source_ip);
    new_user.port = source_port;
    switch (msg->command) {
        case IPMSG_BR_ENTRY:
            user_list_add(comm->user_list, &new_user);
            communicator_send_ans_entry(comm, source_ip, source_port);
            break;
        case IPMSG_ANSENTRY:
            user_list_add(comm->user_list, &new_user);
            break;
        case IPMSG_BR_EXIT:
            user_list_remove(comm->user_list, source_ip, source_port);
            break;
    }
}

// --- 模拟广播辅助函数 ---
static void simulate_broadcast(communicator_t* comm, const char* buffer, int len) {
    if (!comm || comm->sock == INVALID_SOCKET || !buffer || len <= 0) return;
    struct sockaddr_in dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.sin_family = AF_INET;
    inet_pton(AF_INET, "127.0.0.1", &dest_addr.sin_addr);
    for (int port = SIMULATED_BROADCAST_PORT_START; port <= SIMULATED_BROADCAST_PORT_END; ++port) {
        dest_addr.sin_port = htons((uint16_t)port);
        sendto(comm->sock, buffer, len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
    }
}

// --- 公共接口函数 ---
int communicator_init(communicator_t* comm, user_list_t* user_list, struct Console* console, const char* user_name, int port) {
    if (!comm || !user_list || !console || !user_name) return -1;
    comm->user_list = user_list;
    comm->console = console;
    comm->is_running = 1;
    comm->packet_counter = (uint64_t)time(NULL);
    strcpy_s(comm->user_name, sizeof(comm->user_name), user_name);
    gethostname(comm->host_name, sizeof(comm->host_name));
    comm->sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (comm->sock == INVALID_SOCKET) return -1;
    int broadcast_enable = 1;
    if (setsockopt(comm->sock, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast_enable, sizeof(broadcast_enable)) == SOCKET_ERROR) {
        closesocket(comm->sock);
        return -1;
    }
    DWORD dwBytesReturned = 0;
    BOOL bNewBehavior = FALSE;

    // --- 在这里添加诊断代码 ---
#ifndef _WIN32_WINNT
#error _WIN32_WINNT is NOT defined! Build configuration is wrong.
#elif _WIN32_WINNT < 0x0600
#error _WIN32_WINNT is defined but its value is too low!
#endif
    // --- 诊断代码结束 ---

//直接进行手动定义
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif

    WSAIoctl(comm->sock, SIO_UDP_CONNRESET, &bNewBehavior, sizeof(bNewBehavior), NULL, 0, &dwBytesReturned, NULL, NULL);
    struct sockaddr_in local_addr;
    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_port = htons((uint16_t)port);
    local_addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(comm->sock, (struct sockaddr*)&local_addr, sizeof(local_addr)) == SOCKET_ERROR) {
        closesocket(comm->sock);
        return -1;
    }
    comm->listen_thread_handle = _beginthreadex(NULL, 0, communicator_listen_loop, comm, 0, NULL);
    if (comm->listen_thread_handle == 0) {
        closesocket(comm->sock);
        return -1;
    }
    return 0;
}

void communicator_destroy(communicator_t* comm) {
    if (!comm) return;
    comm->is_running = 0;
    if (comm->sock != INVALID_SOCKET) {
        closesocket(comm->sock);
        comm->sock = INVALID_SOCKET;
    }
    if (comm->listen_thread_handle != 0) {
        WaitForSingleObject((HANDLE)comm->listen_thread_handle, INFINITE);
        CloseHandle((HANDLE)comm->listen_thread_handle);
    }
}

void communicator_broadcast_entry(communicator_t* comm) {
    if (!comm) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = build_entry_packet(buffer, sizeof(buffer), comm->packet_counter++, comm->user_name, comm->host_name);
    if (packet_len > 0) simulate_broadcast(comm, buffer, packet_len);
}

void communicator_broadcast_exit(communicator_t* comm) {
    if (!comm) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = build_exit_packet(buffer, sizeof(buffer), comm->packet_counter++, comm->user_name, comm->host_name);
    if (packet_len > 0) simulate_broadcast(comm, buffer, packet_len);
}

void communicator_send_ans_entry(communicator_t* comm, const char* dest_ip, uint16_t dest_port) {
    if (!comm || comm->sock == INVALID_SOCKET) return;
    char buffer[MAX_PACKET_LEN] = {0};
    int packet_len = snprintf(buffer, sizeof(buffer), "%d:%llu:%s:%s:%u:%s", IPMSG_PROTOCOL_VERSION, comm->packet_counter++, comm->user_name, comm->host_name, IPMSG_ANSENTRY, comm->user_name);
    if (packet_len < 0) return;
    struct sockaddr_in dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(dest_port);
    inet_pton(AF_INET, dest_ip, &dest_addr.sin_addr);
    sendto(comm->sock, buffer, packet_len, 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr));
}