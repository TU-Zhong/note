#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

#define IPMSG_PROTOCOL_VERSION 1
#define IPMSG_DEFAULT_PORT 2425

typedef enum {
    IPMSG_NOOP           = 0,
    IPMSG_BR_ENTRY       = 1,
    IPMSG_BR_EXIT        = 2,
    IPMSG_ANSENTRY       = 3,
    IPMSG_SENDMSG        = 32,
} ipmsg_command_t;

#define IPMSG_FILEATTACHOPT 0x00200000

#endif //PROTOCOL_H