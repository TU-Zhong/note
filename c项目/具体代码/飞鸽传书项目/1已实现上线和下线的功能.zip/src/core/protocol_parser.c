#include "core/protocol_parser.h"
#include "core/protocol.h"
#include <string.h>
#include <stdio.h>

int build_entry_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name) {
    if (buffer == NULL || user_name == NULL || host_name == NULL) {
        return -1;
    }

    int main_part_len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:",
        IPMSG_PROTOCOL_VERSION, packet_no, user_name, host_name, IPMSG_BR_ENTRY);

    if (main_part_len < 0 || (size_t)main_part_len >= buffer_size) {
        return -2;
    }

    size_t user_len = strlen(user_name);
    if ((size_t)main_part_len + user_len + 2 > buffer_size) {
        return -2;
    }
    memcpy(buffer + main_part_len, user_name, user_len);
    buffer[main_part_len + user_len] = '\0';
    buffer[main_part_len + user_len + 1] = '\0';

    return main_part_len + (int)user_len + 2;
}

int build_exit_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name) {
    if (buffer == NULL || user_name == NULL || host_name == NULL) {
        return -1;
    }

    int len = snprintf(buffer, buffer_size, "%d:%llu:%s:%s:%u:%s",
        IPMSG_PROTOCOL_VERSION, packet_no, user_name, host_name, IPMSG_BR_EXIT, user_name);

    if (len < 0 || (size_t)len >= buffer_size) {
        return -2;
    }
    return len;
}

int parse_message(const char* packet, size_t packet_len, parsed_message_t* out_msg) {
    if (packet == NULL || out_msg == NULL || packet_len == 0) {
        return -1;
    }

    unsigned int command_and_options;
    int items_scanned = sscanf_s(packet, "%d:%llu:%[^:]:%[^:]:%u:",
        &out_msg->version,
        &out_msg->packet_no,
        out_msg->sender_name, (unsigned)_countof(out_msg->sender_name),
        out_msg->sender_host, (unsigned)_countof(out_msg->sender_host),
        &command_and_options);

    if (items_scanned != 5) {
        return -2;
    }

    out_msg->command = command_and_options & 0xFF;
    out_msg->option = command_and_options;

    const char* additional_start = packet;
    for (int i = 0; i < 5; ++i) {
        if ((additional_start = strchr(additional_start, ':')) == NULL) return -2;
        additional_start++;
    }

    size_t main_part_len = additional_start - packet;
    if (main_part_len >= packet_len) {
        out_msg->additional_section[0] = '\0';
    } else {
        size_t additional_len = packet_len - main_part_len;
        if (additional_len >= sizeof(out_msg->additional_section)) {
            additional_len = sizeof(out_msg->additional_section) - 1;
        }
        memcpy(out_msg->additional_section, additional_start, additional_len);
        out_msg->additional_section[additional_len] = '\0';
    }

    return 0;
}