#ifndef CONSOLE_H
#define CONSOLE_H

#include <windows.h>
#include "../model/user.h"

typedef void (*command_callback_t)(void* context, int argc, char* argv[]);

typedef struct Console {
    CRITICAL_SECTION print_lock;
    volatile int should_exit;
    command_callback_t list_users_cb;
    command_callback_t send_file_cb;
    command_callback_t exit_app_cb;
    void* callback_context;
} console_t;

int console_init(console_t* console);
void console_destroy(console_t* console);
void console_register_callbacks(console_t* console, void* context, command_callback_t list_cb, command_callback_t send_cb, command_callback_t exit_cb);
void console_run(console_t* console);
void console_print_message(console_t* console, const char* message);
void console_display_users(console_t* console, user_list_t* user_list);

#endif //CONSOLE_H