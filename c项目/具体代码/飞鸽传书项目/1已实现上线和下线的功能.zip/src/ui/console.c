#include "ui/console.h"
#include <stdio.h>
#include <string.h>

int console_init(console_t* console) {
    if (!console) return -1;
    console->should_exit = 0;
    console->list_users_cb = NULL;
    console->send_file_cb = NULL;
    console->exit_app_cb = NULL;
    console->callback_context = NULL;
    InitializeCriticalSection(&console->print_lock);
    return 0;
}

void console_destroy(console_t* console) {
    if (!console) return;
    DeleteCriticalSection(&console->print_lock);
}

void console_register_callbacks(console_t* console, void* context, command_callback_t list_cb, command_callback_t send_cb, command_callback_t exit_cb) {
    if (!console) return;
    console->callback_context = context;
    console->list_users_cb = list_cb;
    console->send_file_cb = send_cb;
    console->exit_app_cb = exit_cb;
}

void console_run(console_t* console) {
    char buffer[256];
    while (!console->should_exit) {
        printf("> ");
        fflush(stdout);

        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            buffer[strcspn(buffer, "\r\n")] = 0;

            if (strcmp(buffer, "list") == 0) {
                if (console->list_users_cb) {
                    console->list_users_cb(console->callback_context, 0, NULL);
                }
            } else if (strcmp(buffer, "exit") == 0) {
                if (console->exit_app_cb) {
                    console->exit_app_cb(console->callback_context, 0, NULL);
                }
            } else {
                if (strlen(buffer) > 0) {
                    console_print_message(console, "Unknown command.");
                }
            }
        } else {
            if (console->exit_app_cb) {
                console->exit_app_cb(console->callback_context, 0, NULL);
            }
        }
    }
}

void console_print_message(console_t* console, const char* message) {
    if (!console || !message) return;
    EnterCriticalSection(&console->print_lock);
    printf("\r%s\n", message);
    if (!console->should_exit) {
        printf("> ");
        fflush(stdout);
    }
    LeaveCriticalSection(&console->print_lock);
}

void console_display_users(console_t* console, user_list_t* user_list) {
    if (!console || !user_list) return;

    user_node_t users_snapshot[128];
    int count = user_list_get_all(user_list, users_snapshot, 128);

    EnterCriticalSection(&console->print_lock);
    printf("\r--- Online Users (%d) ---\n", count);
    if (count == 0) {
        printf("No other users found.\n");
    } else {
        for (int i = 0; i < count; ++i) {
            printf("[%d] %s (%s @ %s)\n", i,
                   users_snapshot[i].userName,
                   users_snapshot[i].hostName,
                   users_snapshot[i].ipAddress);
        }
    }
    printf("-------------------------\n");
    if (!console->should_exit) {
        printf("> ");
        fflush(stdout);
    }
    LeaveCriticalSection(&console->print_lock);
}