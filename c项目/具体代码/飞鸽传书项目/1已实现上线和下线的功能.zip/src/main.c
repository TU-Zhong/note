// 1. 首先包含我们自己的核心头文件，它会间接包含 <winsock2.h>
#include "core/communicator.h"
#include "core/protocol.h"
#include "core/protocol_parser.h"
#include "ui/console.h"
#include "model/user.h"

// 2. 然后包含C标准库和Windows系统头文件
#include <stdio.h>
#include <process.h>    // For _beginthreadex
#include <ws2tcpip.h>   // For inet_pton

// 3. 【关键】最后包含 Mstcpip.h，因为它依赖于 winsock2.h
#include <Mstcpip.h>    // For SIO_UDP_CONNRESET

// 主程序上下文结构体，用于在回调函数中传递核心模块
typedef struct {
    user_list_t* user_list;
    console_t* console;
    communicator_t* communicator;
} app_context_t;

// 回调函数的前向声明
static void on_list_command(void* context, int argc, char* argv[]);
static void on_exit_command(void* context, int argc, char* argv[]);

int main(int argc, char* argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <UserName> [Port]\n", argv[0]);
        return 1;
    }
    const char* user_name = argv[1];
    int port = (argc > 2) ? atoi(argv[2]) : IPMSG_DEFAULT_PORT;

    printf("Starting user '%s' on port %d...\n", user_name, port);

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    // 声明所有核心模块
    user_list_t user_list;
    console_t console;
    communicator_t communicator;
    app_context_t context = { &user_list, &console, &communicator };

    // 按顺序初始化
    user_list_init(&user_list);
    console_init(&console);
    if (communicator_init(&communicator, &user_list, &console, user_name, port) != 0) {
        fprintf(stderr, "Fatal: Communicator initialization failed. Exiting.\n");
        console_destroy(&console);
        user_list_destroy(&user_list);
        WSACleanup();
        return 1;
    }

    // 注册回调函数
    console_register_callbacks(&console, &context, on_list_command, NULL, on_exit_command);

    // 广播上线消息
    communicator_broadcast_entry(&communicator);

    // 运行控制台循环（这将阻塞主线程）
    console_run(&console);

    // --- 程序退出流程 ---
    printf("Exiting...\n");
    communicator_broadcast_exit(&communicator);

    // 按初始化的逆序销毁组件
    communicator_destroy(&communicator);
    console_destroy(&console);
    user_list_destroy(&user_list);

    WSACleanup();
    return 0;
}

// --- 回调函数的实现 ---
static void on_list_command(void* context, int argc, char* argv[]) {
    app_context_t* app = (app_context_t*)context;
    // 添加诊断日志，打印 user_list 的内存地址
    printf("DEBUG: Main Thread is accessing user_list at address: %p\n", (void*)app->user_list);
    console_display_users(app->console, app->user_list);
}

static void on_exit_command(void* context, int argc, char* argv[]) {
    app_context_t* app = (app_context_t*)context;
    app->console->should_exit = 1;
}