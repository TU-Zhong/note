#ifndef PROTOCOL_PARSER_H
#define PROTOCOL_PARSER_H

#include <stdint.h>
#include <stddef.h>
#include "../model/user.h"

#define MAX_PACKET_LEN 4096
#define MAX_ADDITIONAL_LEN 2048

typedef struct {
    int version;
    uint64_t packet_no;
    char sender_name[MAX_NAME_LEN];
    char sender_host[MAX_HOSTNAME_LEN];
    uint32_t command;
    uint32_t option;
    char additional_section[MAX_ADDITIONAL_LEN];
} parsed_message_t;

int build_entry_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name);
int build_exit_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name);
int parse_message(const char* packet, size_t packet_len, parsed_message_t* out_msg);

#endif //PROTOCOL_PARSER_H
int build_sendmsg_packet(char* buffer, size_t buffer_size, uint64_t packet_no, const char* user_name, const char* host_name, const char* message);